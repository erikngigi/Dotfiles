#!/bin/bash
#Passwords

echo -e "Enter Password"

stty echo
read password
echo password read
