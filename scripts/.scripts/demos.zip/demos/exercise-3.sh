#!/bin/bash
echo $age
