#!/bin/bash

length=${var}
var=464564564564654564564

echo ${length}
