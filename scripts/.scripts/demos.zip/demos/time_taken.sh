#!/bin/bash

start=$(date +%s)

end=$(date +%s)
diffrence=$(( end - start ))
echo Time take for the program to complete is $diffrence seconds
