#!/bin/bash

fruit=apple
count=5

echo "We have $count $fruit(s) in the freezer"
