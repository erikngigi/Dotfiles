#!/bin/bash

trap "ls -al" 1 2

echo This is line 1
sleep 2 
echo This is line 2
sleep 2 
echo This is line 3
sleep 2 
echo This is line 4
sleep 2 
echo This is line 5
sleep 1
echo This is line 6
sleep 1
echo This is line 7
sleep 1
echo This is line 8
sleep 1
echo This is line 9
sleep 1
