#!/bin/bash

#calculate marks of the students

printf "%-5s %-10s %-4s\n" No Student Marks
printf "%-5s %-10s %-4.4f\n" 1 James 54.4542345
printf "%-5s %-10s %-4.4f\n" 2 Charles 343.1231
printf "%-5s %-10s %-4.4f\n" 3 Kevin 4523.3434
echo -e "\e[1;42m This is a red text colour \e[0m"
